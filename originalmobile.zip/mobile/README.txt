Installation
=============

MAKE SURE THIS PLUGIN IS AT THE "TOP" OF YOUR PLUGINS LIST. This will prevent conflict with the custom index plugin.

Copyright
=========
Copyright Kramnorth 2012. 

This plugin is released under the GNU General Public License, version 2. Please see http://www.gnu.org/licenses/gpl-2.0.html for more information. 
   

Donations
=========

Donating to this plugin will improve development.   
