<?php
/**
 * metatags to show mobile thmem
 * written by Mark Harding @ kramnorth
 * copyright Kramnorth 2011
 */
?>
<!--Displaying Mobile Theme -->