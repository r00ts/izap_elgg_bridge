<?php

echo elgg_echo("wiauction:cancel", array(
    wi_get_my_entities_link("wiauction", "cancelled"),
        wi_get_my_entities_link("wiauction", "active")
));


