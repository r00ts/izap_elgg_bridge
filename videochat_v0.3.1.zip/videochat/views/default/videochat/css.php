<?php ?>
.videochat_listing_actions {
	float: right;
}

.videochat_listing_actions a:hover {
	color: white;
	text-decoration: none;
}

.videochat_settings_info {
	color: gray;
	padding-bottom: 5px;
}

#videochat_popout a{
	float: right;
	
}	

#videochat_popout span{
	display: none;
}