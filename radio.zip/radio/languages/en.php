<?php

	$english = array(
	
		'help' => "Online Radio",
		
		'onx5radio_frameme:onx5radio' => "Online Radio",
	);

	add_translation("en",$english);

?>
