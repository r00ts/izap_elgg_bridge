<?php

	$russian = array(
	
		'help' => "Oнлайн Радио",
		
		'onx5radio_frameme:onx5radio' => "Онлайн Радио",
	);

	add_translation("ru",$russian);

?>
