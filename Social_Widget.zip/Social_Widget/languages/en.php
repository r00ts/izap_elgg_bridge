<?php
/**
* Social Language for Social Widget
*
 */


$english = array('social_Widget:Widget' => 'My Twitter','social_Widget:user' => 'Enter your Twitter Username only<br />we will add the @ in front for you!','social_Widget:no_user' => 'You need to enter your username before using this widget','social_Widget:WidgetDescription' => 'This widget displays your tweets and mentions',);
add_translation("en",$english);
