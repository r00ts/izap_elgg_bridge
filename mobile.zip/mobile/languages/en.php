<?php

	$english = array(
	
		/**
		 * Menu items and titles
		 */
	
			'mobile:river:what' => "What's on your mind?",
			'mobile:river:title' => "Activity Stream",
			'mobile:profile:activity' => "Activity",
			'mobile:profile:info' => "Info",
			'mobile:needaccount' => "Need an account?",
			'mobile:signup' => "Sign up here.",
			'mobile:full' => "Full Site",
			'mobile:mobile' => "Mobile",
			'Share!' => "Share!"
	
	);
					
	add_translation("en",$english);

?>