<?php
/**
 * Button area for showing the add widgets panel
 */
?>
<div class="elgg-widget-add-control">
	<a class="elgg-button elgg-button-action elgg-toggler" data-role="none" href="#widgets-add-panel" rel="toggle">
		<?php echo elgg_echo('widgets:add'); ?>
	</a>
</div>
