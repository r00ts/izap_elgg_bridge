<?php
/**
 * Specific css for the elgg mobile plugin
 * written by Mark Harding @ kramnorth
 * copyright Kramnorth 2011
 */
?>

.logo_centre{
margin:auto;
width:100%;
height:50px;
}
img.logo_centre{
height:22px;
width:42px;
 display: block;
  margin-left: auto;
  margin-right: auto;
}
.elgg-menu-extras-default{
display:none;
}
.elgg-header{
	background-color:#999;
    }
.elgg-header .ui-btn-corner-all {
	-moz-border-radius: 				0 /*{global-radii-buttons}*/;
	-webkit-border-radius: 			0 /*{global-radii-buttons}*/;
	border-radius: 					0 /*{global-radii-buttons}*/;
    }
    
/*INPUT FIELD AND BUTTON MODS */
fieldset > div {
	margin-bottom: 15px;
    padding-left:10px;
}

/* Widgets settings 
 */
.elgg-menu.elgg-menu-widget.elgg-menu-hz.elgg-menu-widget-default{
	display:none;
<<<<<<< HEAD
}

/* Widgets layouts
 */
.elgg-col-1of3, .elgg-col-2of3, .elgg-col-3of3{
	width:100%;
    }
=======
}
>>>>>>> ed4967aef9fc04ffb397cf013d778240d3c4deac
