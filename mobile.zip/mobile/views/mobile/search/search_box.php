<?php
/**
 * Search box
 *
 * @uses $vars['value'] Current search query
 *
 * @todo Move javascript into something that extends elgg.js
 */


///Move to the sidebar

elgg_extend_view('page/elements/body', 'search/search_box_mobile');