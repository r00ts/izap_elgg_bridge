<?php
/**
 * Elgg header logo
 */

$site = elgg_get_site_entity();
$site_name = $site->name;
$site_url = elgg_get_site_url();
?>
<div id="banner"><div id="easylogo"><a href="/index.php"><img  src="/mod/easytheme_slide/img/logo.gif"   alt=""  /></a>
</div></div>
<div id="mmtop">
<!-- this is where the content slider will go... -->
<img style="margin-left:130px;" src="/mod/easytheme_slide/img/slide.gif">
</div>

