
#homepage-cms .elgg-widget-instance-free_html, .elgg-widget-instance-free_html .elgg-body {
  overflow: visible;
}

.homepage-cms-column-header {
  text-align: center;
  background-color: yellow;
  border: 1px dashed #ff0000;
  color: black;
}
