
	<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/tidypics/vendors/uploadify/swfobject.js"></script>
	<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/tidypics/vendors/uploadify/jquery.uploadify.v2.1.1.min.js"></script>

