
<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/tidypics/vendors/PicLensLite/piclens_optimized.js"></script>
