We've spent many hours creating free plugins for Elgg. Please take a minute to give something back by liking 
us on facebook http://www.facebook.com/webintelligence.ie and following us on twitter https://twitter.com/webint_ie


To run:
1/ Go to www.elggstore.webintelligence.ie and download the latest Web Intelligence Framework

2/ Enable the framework, then job and quote plugins

3/ In admin go to settings > WI categories and click add to add a category

4/ Go to Job plugin settings to set the currency and whether only admins can upload jobs