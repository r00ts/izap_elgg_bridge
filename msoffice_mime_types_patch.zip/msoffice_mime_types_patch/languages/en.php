<?php
/**
 * Elgg log browser plugin language pack
 *
 * @package ElggLogBrowser
 */

$english = array(
	'admin:msoffice_mime_types_patch' => 'Mime Types Patch',
);

add_translation("en", $english);