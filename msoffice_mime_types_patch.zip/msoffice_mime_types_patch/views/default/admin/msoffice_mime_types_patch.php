<?php
echo elgg_view_form("msoffice_mime_types_patch/fixit");
?>