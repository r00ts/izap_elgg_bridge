<?php
/**************************************************
* PluginLotto.com                                 *
* Copyrights (c) 2005-2010. iZAP                  *
* All rights reserved                             *
***************************************************
* @author iZAP Team "<support@izap.in>"
* @link http://www.izap.in/
* @version
* Under this agreement, No one has rights to sell this script further.
* For more information. Contact "Tarun Jangra<tarun@izap.in>"
* For discussion about corresponding plugins, visit http://www.pluginlotto.com/pg/forums/
* Follow us on http://facebook.com/PluginLotto and http://twitter.com/PluginLotto
*/
?>
<div class="list-entities-byizap">
  <?php if(is_array($vars['entities'])&&sizeof($vars['entities'])) :        
        echo elgg_view_entity_list($vars['entities'], $vars['count'], $vars['options']['offset'],
          $vars['options']['limit'], $vars['options']['full_view'], $vars['options']['view_type_toggle'], $vars['options']['pagination']);
    
  endif;
  ?>
</div>