<?php
/**************************************************
* PluginLotto.com                                 *
* Copyrights (c) 2005-2010. iZAP                  *
* All rights reserved                             *
***************************************************
* @author iZAP Team "<support@izap.in>"
* @link http://www.izap.in/
* @version
* Under this agreement, No one has rights to sell this script further.
* For more information. Contact "Tarun Jangra<tarun@izap.in>"
* For discussion about corresponding plugins, visit http://www.pluginlotto.com/pg/forums/
* Follow us on http://facebook.com/PluginLotto and http://twitter.com/PluginLotto
*/
?>
<div class="layout-listentities-left-col-byizap">
  <?php if (isset($vars['area1'])) echo $vars['area1']; ?>
</div>

<div class="layout-listentities-right-col-byizap">
  <?php if (isset($vars['area2'])) echo $vars['area2']; ?>
  
  <div class="layout-listentities-right-col2-byizap">
    <?php if (isset($vars['area3'])) echo $vars['area3']; ?>
  </div>
</div>

<div class="clearfloat"></div>