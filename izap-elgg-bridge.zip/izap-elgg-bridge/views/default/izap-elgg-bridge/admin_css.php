<?php

/**************************************************
* PluginLotto.com                                 *
* Copyrights (c) 2005-2010. iZAP                  *
* All rights reserved                             *
***************************************************
* @author iZAP Team "<support@izap.in>"
* @link http://www.izap.in/
* Under this agreement, No one has rights to sell this script further.
* For more information. Contact "Tarun Jangra<tarun@izap.in>"
* For discussion about corresponding plugins, visit http://www.pluginlotto.com/pg/forums/
* Follow us on http://facebook.com/PluginLotto and http://twitter.com/PluginLotto
 */

?>
.izap_admin_fieldset legend{
font-size: 1.2em; padding: 5px; border: 2px solid #DEDEDE; margin-left: 20px;
}
.izap_admin_fieldset {
 border: 2px solid #DEDEDE; margin: 0 0 20px 0;
}
.izap_admin_fieldset p{
margin: 10px;
}