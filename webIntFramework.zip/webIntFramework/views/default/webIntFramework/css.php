<?php
/**
 * Web Intelligence Framwork
 * @package framework
 * @author Mark Kelly
 * @copyright Web intelligence 2012 - 2013
 * @link www.webintelligence.ie
 * @version 1.1 
 */

?>

#selected-cat{
	font-weight:bold;
	background-color: #CEFF16;	
}


.add-float-right{
float:right;
}