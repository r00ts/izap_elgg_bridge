Web Intelligence Framework
=========================
We've spent many hours creating free plugins for Elgg. Please take a minute to give something back by liking 
us on facebook http://www.facebook.com/webintelligence.ie and following us on twitter https://twitter.com/webint_ie


This plugin contains libraries of function used in Web Intelligence plugins. Install with our plugins
when advised to do so.