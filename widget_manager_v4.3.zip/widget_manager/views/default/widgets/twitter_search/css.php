<?php 
	// fixes a nasty z-index in twitter search widget
?>
.elgg-widget-instance-twitter_search .twtr-timeline {
	z-index: 0 !important;
}